import json
import urllib.error
from unittest.mock import MagicMock, call, patch
from urllib.parse import parse_qs, urlparse

import pytest

import currency_client
from currency_client import CurrencyClientError, get_rate


def response_with_rate(rate):
    response = MagicMock()
    response.getcode.return_value = 200
    response.read.return_value = json.dumps({"rates": {"BRL": rate}}).encode("utf-8")
    response.__enter__.return_value = response
    return response


def test_get_rate_uses_source_currency_and_caches_success(tmp_path):
    cache = tmp_path / "rates.sqlite3"
    requests = []

    def open_request(request, timeout):
        requests.append((request, timeout))
        return response_with_rate(5.25)

    with (
        patch.object(currency_client, "CACHE_PATH", cache),
        patch.object(
            currency_client.urllib.request, "urlopen", side_effect=open_request
        ) as urlopen,
    ):
        assert get_rate("usd") == 5.25
        assert get_rate("USD") == 5.25
        assert urlopen.call_count == 1

    query = parse_qs(urlparse(requests[0][0].full_url).query)
    assert query == {"base": ["USD"], "symbols": ["BRL"]}
    assert requests[0][1] == currency_client.REQUEST_TIMEOUT_SECONDS


def test_get_rate_refreshes_expired_cache(tmp_path):
    current_time = [1_000.0]
    rates = iter((4.8, 5.1))
    requests = []

    def open_request(request, timeout):
        requests.append(request)
        return response_with_rate(next(rates))

    with (
        patch.object(currency_client, "CACHE_PATH", tmp_path / "rates.sqlite3"),
        patch.object(currency_client.time, "time", side_effect=lambda: current_time[0]),
        patch.object(
            currency_client.urllib.request, "urlopen", side_effect=open_request
        ),
    ):
        assert get_rate("EUR") == 4.8
        current_time[0] += currency_client.CACHE_TTL_SECONDS + 1
        assert get_rate("EUR") == 5.1
    assert len(requests) == 2


def test_get_rate_retries_server_errors_with_exponential_backoff(tmp_path):
    attempts = []

    def fail_with_server_error(request, timeout):
        attempts.append(request)
        raise urllib.error.HTTPError(
            request.full_url, 500, "Internal Server Error", {}, None
        )

    with (
        patch.object(currency_client, "CACHE_PATH", tmp_path / "rates.sqlite3"),
        patch.object(
            currency_client.urllib.request,
            "urlopen",
            side_effect=fail_with_server_error,
        ) as urlopen,
        patch.object(currency_client.time, "sleep") as sleep,
    ):
        with pytest.raises(CurrencyClientError, match="status HTTP 500"):
            get_rate("EUR")

    assert len(attempts) == currency_client.MAX_ATTEMPTS
    assert urlopen.call_count == 3
    # Três chamadas totais permitem apenas duas esperas antes de uma nova chamada.
    assert sleep.call_args_list == [call(1), call(2)]


def test_get_rate_rejects_bad_currency_without_request():
    with patch.object(currency_client.urllib.request, "urlopen") as urlopen:
        with pytest.raises(ValueError, match="código ISO 4217"):
            get_rate("US")
    urlopen.assert_not_called()


def test_brl_rate_is_one_without_cache_or_request():
    with (
        patch.object(currency_client, "_get_cached_rate") as cached_rate,
        patch.object(currency_client.urllib.request, "urlopen") as urlopen,
    ):
        assert get_rate("brl") == 1.0
    cached_rate.assert_not_called()
    urlopen.assert_not_called()
