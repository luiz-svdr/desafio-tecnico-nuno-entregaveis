import argparse
import csv
import json
import logging
import math
import sqlite3
import sys
from datetime import date, datetime
from logging.handlers import RotatingFileHandler
from pathlib import Path
from typing import Any


def _find_project_root(script_path: Path) -> Path:
    """Localiza a raiz pelo banco ou pelo checkout Git."""
    for parent in Path(script_path).resolve().parents:
        # A raiz precisa ter o banco ou pertencer a um checkout; ZIPs sem ambos não são localizáveis.
        if (parent / "cotacoes.db").is_file() or (parent / ".git").exists():
            return parent
    raise FileNotFoundError(
        f"Não foi possível localizar a raiz do projeto a partir de {script_path}; "
        "mantenha cotacoes.db na raiz ou execute dentro do checkout Git"
    )


DATABASE_COLUMNS = (
    "codigo",
    "cliente",
    "criacao",
    "origem",
    "destino",
    "paisorigem",
    "paisdestino",
    "lane",
    "modal",
    "lclfcl",
    "operador",
    "carrier",
    "vendedor",
    "status",
    "validade",
    "department",
    "criador",
    "cntr_peso",
)

CSV_COLUMNS = {
    "quote_id": "codigo",
    "customer": "cliente",
    "creation_date": "criacao",
    "origin_port": "origem",
    "destination_port": "destino",
    "origin_country": "paisorigem",
    "destination_country": "paisdestino",
    "trade_lane": "lane",
    "transport_mode": "modal",
    "container_type": "lclfcl",
    "operator_name": "operador",
    "shipping_carrier": "carrier",
    "sales_rep": "vendedor",
    "quote_status": "status",
    "valid_until": "validade",
    "dept": "department",
    "created_by": "criador",
    "weight_kg": "cntr_peso",
}


class IngestionError(Exception):
    pass


def _record_error(path: Path, position: str, message: str) -> IngestionError:
    """Cria um erro com o arquivo de origem e a posição do registro."""
    return IngestionError(f"{path.name}, {position}: {message}")


def _text(value: Any, path: Path, position: str, column: str) -> str | None:
    """Valida e limpa um campo textual opcional."""
    if value is None:
        return None
    if not isinstance(value, str):
        raise _record_error(path, position, f"o campo {column} deve ser texto")
    value = value.strip()
    return value or None


def _identifier(value: Any, path: Path, position: str) -> int:
    """Converte o código para inteiro ou informa um erro de validação."""
    try:
        if isinstance(value, bool) or value is None or str(value).strip() == "":
            raise ValueError
        identifier = int(value)
        if str(value).strip() not in (str(identifier), f"{identifier}.0"):
            raise ValueError
        return identifier
    except (TypeError, ValueError):
        raise _record_error(path, position, "o campo codigo deve ser um número inteiro") from None


def _date(value: Any, path: Path, position: str, column: str) -> str | None:
    """Normaliza uma data ou timestamp ISO para armazenamento no SQLite."""
    if value is None or (isinstance(value, str) and not value.strip()):
        return None
    if not isinstance(value, str):
        raise _record_error(path, position, f"o campo {column} deve ser uma data ISO")
    value = value.strip()
    try:
        if "T" in value or " " in value:
            return datetime.fromisoformat(value.replace("Z", "+00:00")).isoformat(sep=" ")
        return date.fromisoformat(value).isoformat()
    except ValueError:
        raise _record_error(path, position, f"data inválida no campo {column}: {value}") from None


def _weight(value: Any, path: Path, position: str) -> float | None:
    """Converte o peso para número finito, preservando valores vazios como nulos."""
    if value is None or (isinstance(value, str) and not value.strip()):
        return None
    try:
        weight = float(value)
        if not math.isfinite(weight):
            raise ValueError
        return weight
    except (TypeError, ValueError):
        raise _record_error(path, position, "o campo cntr_peso deve ser numérico") from None


def _normalize_record(values: dict[str, Any], path: Path, position: str) -> dict[str, Any]:
    """Mapeia os campos do fornecedor para o schema de cotacoes."""
    result: dict[str, Any] = {}
    for source_column, database_column in CSV_COLUMNS.items():
        value = values.get(source_column)
        if database_column == "codigo":
            result[database_column] = _identifier(value, path, position)
        elif database_column in ("criacao", "validade"):
            result[database_column] = _date(value, path, position, database_column)
        elif database_column == "cntr_peso":
            result[database_column] = _weight(value, path, position)
        else:
            result[database_column] = _text(value, path, position, database_column)
    return result


def _read_csv(path: Path) -> list[tuple[int, dict[str, Any]]]:
    """Lê e valida os registros CSV do fornecedor A."""
    records: list[tuple[int, dict[str, Any]]] = []
    try:
        with path.open("r", encoding="utf-8-sig", newline="") as source:
            reader = csv.DictReader(source)
            if not reader.fieldnames:
                raise _record_error(path, "cabeçalho", "arquivo CSV vazio ou sem cabeçalho")
            if len(reader.fieldnames) != len(set(reader.fieldnames)):
                raise _record_error(path, "cabeçalho", "nomes de coluna duplicados")
            missing = sorted(set(CSV_COLUMNS) - set(reader.fieldnames))
            if missing:
                raise _record_error(
                    path, "cabeçalho", f"colunas obrigatórias ausentes: {', '.join(missing)}"
                )
            for line_number, row in enumerate(reader, start=2):
                position = f"linha {line_number}"
                if None in row or None in row.values():
                    raise _record_error(path, position, "quantidade de campos diferente do cabeçalho")
                records.append((line_number, _normalize_record(row, path, position)))
    except UnicodeDecodeError as error:
        raise _record_error(path, f"byte {error.start}", "arquivo não está codificado em UTF-8") from None
    except csv.Error as error:
        raise _record_error(path, "CSV", str(error)) from None
    return records


def _json_value(record: dict[str, Any], section: str, key: str, path: Path, position: str) -> Any:
    """Obtém um campo obrigatório de um objeto JSON aninhado."""
    value = record.get(section)
    if not isinstance(value, dict) or key not in value:
        raise _record_error(path, position, f"campo obrigatório ausente: {section}.{key}")
    return value[key]


def _read_json(path: Path) -> list[tuple[int, dict[str, Any]]]:
    """Lê, valida e normaliza os registros JSON do fornecedor B."""
    try:
        with path.open("r", encoding="utf-8") as source:
            data = json.load(source)
    except UnicodeDecodeError as error:
        raise _record_error(path, f"byte {error.start}", "arquivo não está codificado em UTF-8") from None
    except json.JSONDecodeError as error:
        raise _record_error(path, f"linha {error.lineno}, coluna {error.colno}", error.msg) from None

    if not isinstance(data, dict) or not isinstance(data.get("shipments"), list):
        raise _record_error(path, "estrutura", "esperada uma lista shipments no objeto JSON")

    records: list[tuple[int, dict[str, Any]]] = []
    for index, record in enumerate(data["shipments"], start=1):
        position = f"registro {index}"
        if not isinstance(record, dict):
            raise _record_error(path, position, "o registro deve ser um objeto")
        values = {
            "quote_id": record.get("qid"),
            "customer": record.get("cust"),
            "creation_date": record.get("cdate"),
            "origin_port": _json_value(record, "route", "oport", path, position),
            "destination_port": _json_value(record, "route", "dport", path, position),
            "origin_country": _json_value(record, "route", "ocountry", path, position),
            "destination_country": _json_value(record, "route", "dcountry", path, position),
            "trade_lane": _json_value(record, "route", "lane", path, position),
            "transport_mode": _json_value(record, "cargo", "mode", path, position),
            "container_type": _json_value(record, "cargo", "ctype", path, position),
            "weight_kg": _json_value(record, "cargo", "wt", path, position),
            "operator_name": _json_value(record, "parties", "op", path, position),
            "shipping_carrier": _json_value(record, "parties", "carr", path, position),
            "sales_rep": _json_value(record, "parties", "sales", path, position),
            "created_by": _json_value(record, "parties", "creator", path, position),
            "quote_status": _json_value(record, "status", "stat", path, position),
            "valid_until": _json_value(record, "status", "valid", path, position),
            "dept": record.get("dept"),
        }
        for field in ("qid", "cust", "cdate"):
            if field not in record:
                raise _record_error(path, position, f"campo obrigatório ausente: {field}")
        records.append((index, _normalize_record(values, path, position)))
    return records


def _validate_database(connection: sqlite3.Connection) -> None:
    """Valida o schema necessário e cria a tabela de idempotência."""
    table = connection.execute(
        "SELECT 1 FROM sqlite_master WHERE type = 'table' AND name = 'cotacoes'"
    ).fetchone()
    if table is None:
        raise RuntimeError("o banco não contém a tabela cotacoes")
    columns = {row[1] for row in connection.execute("PRAGMA table_info(cotacoes)")}
    missing = set(DATABASE_COLUMNS) - columns
    if missing:
        raise RuntimeError(f"colunas ausentes na tabela cotacoes: {', '.join(sorted(missing))}")
    connection.execute(
        """
        CREATE TABLE IF NOT EXISTS ingested_quotes (
            supplier TEXT NOT NULL,
            codigo INTEGER NOT NULL,
            PRIMARY KEY (supplier, codigo)
        )
        """
    )
    connection.commit()


def _import_file(
    path: Path, connection: sqlite3.Connection, logger: logging.LoggerAdapter
) -> int:
    """Importa um arquivo atomicamente e ignora registros já importados ou conflitantes."""
    supplier = "fornecedor_a" if path.suffix.lower() == ".csv" else "fornecedor_b"
    records = _read_csv(path) if supplier == "fornecedor_a" else _read_json(path)
    inserted = 0
    placeholders = ", ".join("?" for _ in DATABASE_COLUMNS)
    columns = ", ".join(DATABASE_COLUMNS)

    try:
        # A transação reverte todas as alterações do arquivo se ocorrer um erro.
        with connection:
            for index, quote in records:
                position = f"linha {index}" if supplier == "fornecedor_a" else f"registro {index}"
                code = quote["codigo"]
                ingested = connection.execute(
                    "SELECT 1 FROM ingested_quotes WHERE supplier = ? AND codigo = ?",
                    (supplier, code),
                ).fetchone()
                if ingested:
                    logger.info("%s: codigo %s já importado; registro ignorado", path.name, code)
                    continue

                existing = connection.execute(
                    "SELECT 1 FROM cotacoes WHERE codigo = ?", (code,)
                ).fetchone()
                if existing:
                    source = connection.execute(
                        "SELECT supplier FROM ingested_quotes WHERE codigo = ? LIMIT 1", (code,)
                    ).fetchone()
                    if source:
                        logger.warning(
                            "%s: codigo %s já foi importado de %s; conflito com a chave "
                            "única de cotacoes, registro ignorado",
                            path.name,
                            code,
                            source[0],
                        )
                    else:
                        logger.warning(
                            "%s: codigo %s já existe sem origem registrada; registro ignorado",
                            path.name,
                            code,
                        )
                    continue

                values = tuple(quote[column] for column in DATABASE_COLUMNS)
                try:
                    connection.execute(
                        f"INSERT INTO cotacoes ({columns}) VALUES ({placeholders})", values
                    )
                except sqlite3.IntegrityError as error:
                    raise _record_error(path, position, str(error)) from None
                connection.execute(
                    "INSERT INTO ingested_quotes (supplier, codigo) VALUES (?, ?)",
                    (supplier, code),
                )
                inserted += 1
    except IngestionError:
        raise
    except sqlite3.Error as error:
        raise _record_error(path, "banco de dados", str(error)) from None

    return inserted


def run_pipeline(
    input_dir: Path, database_path: Path, logger: logging.Logger
) -> tuple[int, int]:
    """Processa os arquivos de entrada, arquiva sucessos e contabiliza falhas."""
    input_dir = Path(input_dir)
    database_path = Path(database_path)
    if not input_dir.is_dir():
        raise ValueError(f"diretório de entrada não encontrado: {input_dir}")
    if not database_path.is_file():
        raise FileNotFoundError(f"banco de dados não encontrado: {database_path}")

    connection = sqlite3.connect(database_path)
    failures = 0
    total_inserted = 0
    try:
        _validate_database(connection)
        files = sorted(
            path
            for path in input_dir.iterdir()
            if path.is_file() and path.suffix.lower() in (".csv", ".json")
        )
        for path in files:
            file_logger = logging.LoggerAdapter(logger, {"input_file": path.name})
            try:
                inserted = _import_file(path, connection, file_logger)
                archive_dir = input_dir / "processados"
                archive_dir.mkdir(exist_ok=True)
                timestamp = datetime.now().strftime("%Y%m%d_%H%M%S_%f")
                archived_path = archive_dir / f"{path.stem}_{timestamp}{path.suffix}"
                # Se o arquivamento falhar, a próxima execução ignora os gravados e tenta novamente.
                path.replace(archived_path)
                total_inserted += inserted
                file_logger.info(
                    "%s: %s registros inseridos; arquivo movido para %s",
                    path.name,
                    inserted,
                    archived_path,
                )
            except (IngestionError, OSError, sqlite3.Error) as error:
                failures += 1
                file_logger.error("%s", error)
    finally:
        connection.close()

    return total_inserted, failures


def _configure_logging(directory: Path) -> logging.Logger:
    """Configura log rotativo no diretório informado."""
    logger = logging.getLogger("ingestao_cotacoes")
    logger.setLevel(logging.INFO)
    logger.handlers.clear()
    formatter = logging.Formatter(
        "[%(asctime)s] [%(levelname)s] [%(input_file)s] %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S",
        defaults={"input_file": "pipeline"},
    )
    file_handler = RotatingFileHandler(
        directory / "ingestao_cotacoes.log",
        maxBytes=5 * 1024 * 1024,
        backupCount=3,
        encoding="utf-8",
    )
    file_handler.setFormatter(formatter)
    stream_handler = logging.StreamHandler()
    stream_handler.setFormatter(formatter)
    logger.addHandler(file_handler)
    logger.addHandler(stream_handler)
    return logger


def main(argv: list[str] | None = None) -> int:
    """Interpreta os argumentos e executa o pipeline de ingestão."""
    parser = argparse.ArgumentParser(description="Ingere cotações CSV e JSON no banco SQLite.")
    parser.add_argument(
        "--dir",
        type=Path,
        help="diretório monitorado (padrão: <raiz>/specs/data)",
    )
    args = parser.parse_args(argv)
    try:
        root_dir = _find_project_root(Path(__file__))
    except FileNotFoundError as error:
        parser.error(str(error))

    input_dir = (args.dir or root_dir / "specs" / "data").expanduser()
    if not input_dir.is_dir():
        parser.error(f"diretório não encontrado: {input_dir}")

    logger = _configure_logging(input_dir)
    try:
        inserted, failures = run_pipeline(
            input_dir, root_dir / "cotacoes.db", logger
        )
    except (OSError, sqlite3.Error, RuntimeError, ValueError) as error:
        logger.error("%s", error)
        return 1
    logger.info(
        "Pipeline concluído: %s registros inseridos; %s arquivo(s) com erro",
        inserted,
        failures,
    )
    return 1 if failures else 0


if __name__ == "__main__":
    sys.exit(main())
