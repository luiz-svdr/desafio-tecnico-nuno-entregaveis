"""Cliente para obter taxas de câmbio em BRL."""

import json
import math
import os
import re
import sqlite3
import time
import urllib.error
import urllib.parse
import urllib.request
from pathlib import Path
from typing import Any


API_URL = "https://api.exemplo.com/v1/rates"
REQUEST_TIMEOUT_SECONDS = 10
CACHE_TTL_SECONDS = 60 * 60
# Três chamadas (a inicial e duas tentativas) pedem esperas de 1s e 2s, sem um quarto ciclo.
MAX_ATTEMPTS = 3
RETRY_BACKOFF_SECONDS = (1, 2)


def _default_cache_path() -> Path:
    """Define o diretório de cache local do usuário."""
    local_app_data = os.environ.get("LOCALAPPDATA")
    cache_dir = Path(local_app_data) if local_app_data else Path.home() / ".cache"
    return cache_dir / "currency_client" / "rates.sqlite3"


CACHE_PATH = _default_cache_path()


class CurrencyClientError(Exception):
    """Erro ao obter ou armazenar uma taxa de conversão."""


def _open_cache() -> sqlite3.Connection:
    """Abre o cache local e garante a tabela de taxas."""
    try:
        CACHE_PATH.parent.mkdir(parents=True, exist_ok=True)
        connection = sqlite3.connect(CACHE_PATH)
        connection.execute(
            """
            CREATE TABLE IF NOT EXISTS currency_rates (
                currency TEXT PRIMARY KEY,
                rate REAL NOT NULL,
                cached_at REAL NOT NULL
            )
            """
        )
        return connection
    except (OSError, sqlite3.Error) as error:
        raise CurrencyClientError(
            f"Não foi possível acessar o cache local de cotações: {error}"
        ) from error


def _get_cached_rate(currency: str) -> float | None:
    """Retorna uma taxa ainda válida e remove entradas expiradas."""
    connection = _open_cache()
    try:
        row = connection.execute(
            "SELECT rate, cached_at FROM currency_rates WHERE currency = ?",
            (currency,),
        ).fetchone()
        if row is None:
            return None

        rate, cached_at = row
        if 0 <= time.time() - cached_at < CACHE_TTL_SECONDS:
            return float(rate)

        connection.execute(
            "DELETE FROM currency_rates WHERE currency = ?", (currency,)
        )
        connection.commit()
        return None
    except sqlite3.Error as error:
        raise CurrencyClientError(
            f"Não foi possível ler o cache local de cotações: {error}"
        ) from error
    finally:
        connection.close()


def _cache_rate(currency: str, rate: float) -> None:
    """Armazena ou atualiza a taxa e seu horário de obtenção."""
    connection = _open_cache()
    try:
        connection.execute(
            """
            INSERT INTO currency_rates (currency, rate, cached_at)
            VALUES (?, ?, ?)
            ON CONFLICT(currency) DO UPDATE SET
                rate = excluded.rate,
                cached_at = excluded.cached_at
            """,
            (currency, rate, time.time()),
        )
        connection.commit()
    except sqlite3.Error as error:
        raise CurrencyClientError(
            f"Não foi possível gravar no cache local de cotações: {error}"
        ) from error
    finally:
        connection.close()


def _parse_rate(response_body: bytes, currency: str) -> float:
    """Valida e extrai a taxa BRL da resposta JSON da API."""
    try:
        payload: Any = json.loads(response_body.decode("utf-8"))
    except (UnicodeDecodeError, json.JSONDecodeError) as error:
        raise CurrencyClientError("A API retornou uma resposta JSON inválida.") from error

    rates = payload.get("rates") if isinstance(payload, dict) else None
    raw_rate = rates.get("BRL") if isinstance(rates, dict) else None
    if isinstance(raw_rate, bool) or not isinstance(raw_rate, (int, float)):
        raise CurrencyClientError(
            f"A API não retornou uma taxa BRL válida para {currency}."
        )

    rate = float(raw_rate)
    if not math.isfinite(rate) or rate <= 0:
        raise CurrencyClientError(
            f"A API não retornou uma taxa BRL válida para {currency}."
        )
    return rate


def _fetch_rate(currency: str) -> float:
    """Consulta a API com timeout e tentativas para falhas transitórias."""
    query = urllib.parse.urlencode({"base": currency, "symbols": "BRL"})
    request = urllib.request.Request(
        f"{API_URL}?{query}",
        headers={"Accept": "application/json"},
    )

    last_error: Exception | None = None
    # O limite inclui a chamada inicial; não há espera após a última tentativa.
    for attempt in range(MAX_ATTEMPTS):
        try:
            with urllib.request.urlopen(
                request, timeout=REQUEST_TIMEOUT_SECONDS
            ) as response:
                status = response.getcode()
                if status >= 400:
                    error = CurrencyClientError(
                        f"A API de câmbio retornou o status HTTP {status}."
                    )
                    if status < 500 or attempt == MAX_ATTEMPTS - 1:
                        raise error
                    last_error = error
                else:
                    return _parse_rate(response.read(), currency)
        except urllib.error.HTTPError as error:
            if error.code < 500 or attempt == MAX_ATTEMPTS - 1:
                raise CurrencyClientError(
                    f"A API de câmbio retornou o status HTTP {error.code}."
                ) from error
            last_error = error
        except (urllib.error.URLError, TimeoutError, OSError) as error:
            if attempt == MAX_ATTEMPTS - 1:
                raise CurrencyClientError(
                    f"Falha ao consultar a API de câmbio: {error}"
                ) from error
            last_error = error

        if attempt < MAX_ATTEMPTS - 1:
            time.sleep(RETRY_BACKOFF_SECONDS[attempt])

    raise CurrencyClientError(
        f"Não foi possível obter a taxa de câmbio: {last_error}"
    )


def get_rate(moeda_origem: str) -> float:
    """Retorna a taxa atual para converter uma unidade da moeda de origem em BRL.

    Consulta a API de câmbio em até três chamadas, repetindo falhas transitórias
    com backoff exponencial, e armazena taxas válidas em cache local por uma hora.
    A resposta esperada da API contém ``{"rates": {"BRL": <taxa>}}``.
    """
    if not isinstance(moeda_origem, str):
        raise ValueError("A moeda de origem deve ser um código ISO 4217.")

    currency = moeda_origem.strip().upper()
    if not re.fullmatch(r"[A-Z]{3}", currency):
        raise ValueError("A moeda de origem deve ser um código ISO 4217.")
    if currency == "BRL":
        return 1.0

    cached_rate = _get_cached_rate(currency)
    if cached_rate is not None:
        return cached_rate

    rate = _fetch_rate(currency)
    _cache_rate(currency, rate)
    return rate
