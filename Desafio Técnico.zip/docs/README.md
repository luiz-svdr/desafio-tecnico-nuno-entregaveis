# Entregáveis — desafio técnico

Esta pasta reúne os arquivos finais dos quatro módulos, sem substituir os
arquivos-fonte originais do projeto.

## Conteúdo

- `sql/`: três consultas do módulo 1.
- `python/`: pipeline de ingestão do módulo 2, cliente de câmbio do módulo 3 e
  seus testes focados.
- `dashboard/`: página, estilos, JavaScript e servidor HTTP do módulo 4. O
  serviço de consulta SQLite está integrado em `server.py`.
- `docs/`: justificativa técnica e resposta ao desafio integrador.

## Requisitos

- Python 3.10 ou superior para os módulos Python e o dashboard.
- `pytest` para executar os testes.
- Navegador com JavaScript habilitado e acesso à internet para carregar Chart.js
  e seu plugin por CDN no dashboard.

Os módulos usam a biblioteca padrão do Python e SQLite; não há dependências
Python externas para execução.

## Como usar

### Consultas SQL

Execute `sql/query_1.sql`, `sql/query_2.sql` e `sql/query_3.sql` em uma conexão
com o banco SQLite do projeto (`cotacoes.db`).

### Ingestão de cotações

Execute `python\ingestao_cotacoes.py` a partir da raiz do pacote e informe a
pasta de entrada com `--dir`. O padrão `specs\data` existe no repositório, mas
essa pasta de dados não acompanha o pacote. Arquivos sem erros são movidos para
uma subpasta `processados` após a importação e os dados são gravados no
`cotacoes.db` da raiz. A importação é atômica por arquivo; colisões de código
entre fornecedores são ignoradas com aviso. Para preservar os arquivos de
exemplo, aponte `--dir` para uma cópia dos dados.

O script identifica a raiz pela presença de `cotacoes.db` ou de `.git` em uma
pasta acima dele. Em um ZIP sem `.git`, mantenha o banco na raiz do projeto;
se o banco ficar fora das pastas acima do script, a raiz não poderá ser
identificada. `--help` pode ser consultado mesmo antes dessa verificação.

```powershell
python ".\python\ingestao_cotacoes.py" --dir "C:\caminho\para\uma\copia dos dados"
```

### Cliente de câmbio

Importe `get_rate` de `currency_client.py` no seu código. A URL do provedor é
configurada pela constante `API_URL` no módulo. O cliente valida a moeda, usa
cache local e lança erros explícitos para falhas de consulta. O limite é de três
chamadas totais, com pausas de 1 e 2 segundos entre chamadas; não há pausa após
a última tentativa.

### Dashboard

Na raiz do projeto, inicie o servidor apontando para o banco SQLite:

```powershell
python ".\dashboard\server.py" --db ".\cotacoes.db"
```

Acesse <http://127.0.0.1:8000/>. O dashboard inclui filtros opcionais e Top 10
de vendedores por cotações aprovadas; o card acompanha o conjunto filtrado. O
servidor deve permanecer ativo enquanto o dashboard estiver em uso. Para
selecionar outra porta, acrescente `--port 8080` ao comando.

## Testes

Execute o teste do cliente de câmbio incluído nesta pasta:

```powershell
python -m pytest ".\python\test_currency_client.py"
```
