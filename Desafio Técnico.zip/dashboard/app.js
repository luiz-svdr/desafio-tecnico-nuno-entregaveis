"use strict";

Chart.register(ChartDataLabels);

const filtersForm = document.getElementById("filters");
const notice = document.getElementById("notice");
const pageSize = 10;
const ALL_LANES_FILTER = "__TODAS_LANES__";
const ALL_SELLERS_FILTER = "__TODOS_VENDEDORES__";
const charts = {};
let currentPage = 1;
let currentData = null;
let dashboardRequestId = 0;
let selectedStatuses = new Set();
const hiddenColumns = new Set();
const columnNames = [
  "Código",
  "Cliente",
  "Data de Criação",
  "Status",
  "Modal",
  "País de Origem",
  "País de Destino",
  "Vendedor",
  "Lane",
];

function token(name) {
  return getComputedStyle(document.documentElement).getPropertyValue(name).trim();
}

function statusColor(key) {
  const colors = {
    APROVADO: token("--color-approved"),
    REJEITADO: token("--color-rejected"),
    ESTUDO: token("--color-study"),
    "SEGUNDA OPCAO": token("--color-alternative"),
    __EMPTY__: token("--color-disabled"),
  };
  return colors[key] || token("--color-disabled");
}

function escapeText(value) {
  return String(value ?? "");
}

function showError(message) {
  notice.textContent = message;
  notice.classList.add("notice--error");
}

function clearError() {
  notice.textContent = "";
  notice.classList.remove("notice--error");
}

function populateSelect(element, values, mapValue) {
  const selected = element.value;
  element.replaceChildren();
  values.forEach((value) => {
    const option = mapValue(value);
    element.add(new Option(option.label, option.value));
  });
  if ([...element.options].some((option) => option.value === selected)) {
    element.value = selected;
  }
}

function updateFilterOptions(data) {
  // Mantém as opções de filtro disponíveis, mesmo quando o recorte atual é restrito.
  const lanes = [
    { value: ALL_LANES_FILTER, label: "Todas as Lanes" },
    ...data.filters.lanes,
  ];
  const sellers = [
    { value: ALL_SELLERS_FILTER, label: "Todos os Vendedores" },
    ...data.filters.sellers.map((seller) => ({ value: seller, label: seller })),
  ];
  populateSelect(
    document.getElementById("lane-filter"),
    lanes,
    (lane) => lane,
  );
  populateSelect(
    document.getElementById("seller-filter"),
    sellers,
    (seller) => seller,
  );
}

function updateDashboardSummary(total = null) {
  const seller = document.getElementById("seller-filter").value;
  const lane = document.getElementById("lane-filter").value;
  const sellerLabel = seller && seller !== ALL_SELLERS_FILTER
    ? `Vendedor ${seller}`
    : "Todos os Vendedores";
  const laneLabel = lane === "__SEM_LANE__"
    ? "Sem Lane"
    : lane && lane !== ALL_LANES_FILTER
      ? lane
      : "Todas as Lanes";
  document.getElementById("dashboard-summary").textContent =
    `${sellerLabel} - ${laneLabel} -`;
  document.getElementById("total-quotes").textContent = total === null
    ? "—"
    : total.toLocaleString("pt-BR");
}

function renderStatusToggles(statuses) {
  const host = document.getElementById("status-toggles");
  const keys = new Set(statuses.map((status) => status.key));
  selectedStatuses = new Set([...selectedStatuses].filter((key) => keys.has(key)));
  if (selectedStatuses.size === 0 && statuses.length > 0) {
    selectedStatuses = new Set(statuses.map((status) => status.key));
  }
  host.replaceChildren();

  statuses.forEach((status) => {
    const label = document.createElement("label");
    label.className = "status-toggle";
    const checkbox = document.createElement("input");
    checkbox.type = "checkbox";
    checkbox.value = status.key;
    checkbox.checked = selectedStatuses.has(status.key);
    checkbox.addEventListener("change", () => {
      if (checkbox.checked) {
        selectedStatuses.add(status.key);
      } else {
        selectedStatuses.delete(status.key);
      }
      renderMonthlyChart(currentData);
    });
    const text = document.createElement("span");
    text.textContent = status.label || "(vazio)";
    text.style.color = statusColor(status.key);
    label.append(checkbox, text);
    host.append(label);
  });
}

function renderMonthlyChart(data) {
  if (!data) return;
  const statuses = data.status_distribution;
  const selected = statuses.filter((status) => selectedStatuses.has(status.key));
  const labels = data.monthly.map((item) => {
    const [year, month] = item.month.split("-");
    return new Intl.DateTimeFormat("pt-BR", {
      month: "short",
      year: "numeric",
      timeZone: "UTC",
    }).format(new Date(Date.UTC(Number(year), Number(month) - 1, 1)));
  });
  const datasets = selected.map((status) => ({
    label: status.label || "(vazio)",
    data: data.monthly.map((item) => item.statuses[status.key] || 0),
    backgroundColor: statusColor(status.key),
    borderWidth: 0,
  }));
  const stacked = selected.length === statuses.length && statuses.length > 0;
  const options = {
    responsive: true,
    maintainAspectRatio: false,
    indexAxis: "y",
    plugins: {
      legend: { display: false },
      datalabels: { display: false },
    },
    scales: {
      x: {
        beginAtZero: true,
        stacked,
        grid: { color: token("--color-grid"), lineWidth: 1 },
        ticks: { color: token("--color-text-secondary"), precision: 0 },
      },
      y: {
        stacked,
        grid: { display: false },
        ticks: { color: token("--color-text-secondary") },
      },
    },
  };
  if (charts.monthly) {
    charts.monthly.data = { labels, datasets };
    charts.monthly.options = options;
    charts.monthly.update();
  } else {
    charts.monthly = new Chart(document.getElementById("monthly-chart"), {
      type: "bar",
      data: { labels, datasets },
      options,
    });
  }
}

function renderStatusChart(data) {
  const statuses = data.status_distribution;
  const labels = statuses.map((status) => status.label || "(vazio)");
  const values = statuses.map((status) => status.count);
  const colors = statuses.map((status) => statusColor(status.key));
  const options = {
    responsive: true,
    maintainAspectRatio: false,
    layout: { padding: { top: 24, right: 32, bottom: 24, left: 32 } },
    plugins: {
      legend: { display: false },
      datalabels: {
        color: token("--color-text"),
        anchor: "end",
        align: "end",
        offset: 8,
        formatter: (value, context) => {
          const total = context.dataset.data.reduce((sum, count) => sum + count, 0);
          return value && total ? `${(value * 100 / total).toFixed(1)}%` : "";
        },
        font: { family: token("--font-family"), size: 12 },
      },
    },
  };
  const chartData = {
    labels,
    datasets: [
      {
        data: values,
        backgroundColor: colors,
        borderColor: token("--color-surface"),
        borderWidth: 2,
      },
    ],
  };
  if (charts.status) {
    charts.status.data = chartData;
    charts.status.options = options;
    charts.status.update();
  } else {
    charts.status = new Chart(document.getElementById("status-chart"), {
      type: "doughnut",
      data: chartData,
      options,
    });
  }

  const legend = document.getElementById("status-legend");
  legend.replaceChildren();
  statuses.forEach((status) => {
    const item = document.createElement("span");
    item.className = "legend-item";
    const swatch = document.createElement("span");
    swatch.className = "legend-swatch";
    swatch.style.backgroundColor = statusColor(status.key);
    const label = document.createElement("span");
    label.textContent = `${status.label || "(vazio)"}: ${status.percentage}%`;
    item.append(swatch, label);
    legend.append(item);
  });
}

function renderLaneChart(data) {
  const labels = data.lane_distribution.map((lane) => lane.lane);
  const values = data.lane_distribution.map((lane) => lane.count);
  const colors = data.lane_distribution.map((lane) =>
    lane.selected ? token("--color-primary") : token("--color-secondary"),
  );
  const chartData = {
    labels,
    datasets: [{ data: values, backgroundColor: colors, borderWidth: 0 }],
  };
  const options = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: { display: false },
      datalabels: {
        color: token("--color-text"),
        anchor: "end",
        align: "end",
        font: { family: token("--font-family"), size: 12, weight: "bold" },
      },
    },
    scales: {
      x: {
        grid: { display: false },
        ticks: { color: token("--color-text-secondary") },
      },
      y: {
        beginAtZero: true,
        grid: { color: token("--color-grid"), lineWidth: 1 },
        ticks: { color: token("--color-text-secondary"), precision: 0 },
      },
    },
  };
  if (charts.lane) {
    charts.lane.data = chartData;
    charts.lane.options = options;
    charts.lane.update();
  } else {
    charts.lane = new Chart(document.getElementById("lane-chart"), {
      type: "bar",
      data: chartData,
      options,
    });
  }
}

function renderTopSellersChart(data) {
  const ranking = data.top_sellers;
  const chartData = {
    labels: ranking.map((item) => item.vendedor),
    datasets: [
      {
        data: ranking.map((item) => item.qtd_aprovadas),
        backgroundColor: token("--color-secondary"),
        borderWidth: 0,
      },
    ],
  };
  const options = {
    indexAxis: "y",
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: { display: false },
      datalabels: {
        color: token("--color-text"),
        anchor: "end",
        align: "end",
        font: { family: token("--font-family"), size: 12, weight: "bold" },
      },
    },
    scales: {
      x: {
        beginAtZero: true,
        grid: { color: token("--color-grid"), lineWidth: 1 },
        ticks: { color: token("--color-text-secondary"), precision: 0 },
      },
      y: {
        grid: { display: false },
        ticks: { color: token("--color-text-secondary") },
      },
    },
  };
  // A API já retorna o ranking filtrado, ordenado e limitado a dez vendedores.
  if (charts.topSellers) {
    charts.topSellers.data = chartData;
    charts.topSellers.options = options;
    charts.topSellers.update();
  } else {
    charts.topSellers = new Chart(document.getElementById("top-sellers-chart"), {
      type: "bar",
      data: chartData,
      options,
    });
  }
}

function renderTable(data) {
  const body = document.getElementById("quotes-body");
  body.replaceChildren();
  data.quotes.forEach((quote) => {
    const row = document.createElement("tr");
    const values = [
      quote.codigo,
      quote.cliente,
      quote.criacao,
      quote.status.label,
      quote.modal,
      quote.paisorigem,
      quote.paisdestino,
      quote.vendedor,
      quote.lane,
    ];
    values.forEach((value, index) => {
      const cell = document.createElement("td");
      if (index === 3) {
        const status = document.createElement("span");
        status.className = "status-cell";
        const dot = document.createElement("span");
        dot.className = "status-dot";
        dot.dataset.statusKey = quote.status.key;
        const label = document.createElement("span");
        label.dataset.statusKey = quote.status.key;
        label.textContent = escapeText(value);
        status.append(dot, label);
        cell.append(status);
      } else {
        cell.textContent = escapeText(value);
      }
      cell.hidden = hiddenColumns.has(index);
      row.append(cell);
    });
    body.append(row);
  });
  if (data.quotes.length === 0) {
    const row = document.createElement("tr");
    const cell = document.createElement("td");
    cell.colSpan = 9;
    cell.textContent = "Nenhuma cotação encontrada.";
    row.append(cell);
    body.append(row);
  }
  document.querySelectorAll("th[data-column-index]").forEach((header) => {
    header.hidden = hiddenColumns.has(Number(header.dataset.columnIndex));
  });
  renderColumnControls();
}

function renderColumnControls() {
  const controls = document.getElementById("column-controls");
  controls.replaceChildren();
  const hint = document.createElement("span");
  hint.textContent = "Duplo clique no cabeçalho para ocultar uma coluna.";
  controls.append(hint);

  [...hiddenColumns].sort((left, right) => left - right).forEach((index) => {
    const button = document.createElement("button");
    button.className = "button button--secondary";
    button.type = "button";
    button.textContent = `Mostrar ${columnNames[index]}`;
    button.setAttribute("aria-label", `Mostrar coluna ${columnNames[index]}`);
    button.addEventListener("click", () => {
      hiddenColumns.delete(index);
      renderTable(currentData);
    });
    controls.append(button);
  });
}

function toggleColumn(index) {
  if (hiddenColumns.has(index)) {
    hiddenColumns.delete(index);
  } else {
    hiddenColumns.add(index);
  }
  renderTable(currentData);
}

function renderPagination(data) {
  // A paginação informa o tamanho do conjunto filtrado recebido do servidor.
  const pagination = data.pagination;
  const first = pagination.total
    ? (pagination.page - 1) * pagination.page_size + 1
    : 0;
  const last = Math.min(pagination.page * pagination.page_size, pagination.total);
  document.getElementById("page-summary").textContent =
    `${first}–${last} de ${pagination.total} registros`;
  document.getElementById("previous-page").disabled = pagination.page <= 1;
  document.getElementById("next-page").disabled =
    pagination.page >= pagination.pages;
}

function restoreFilterState(parameters) {
  const fields = [
    ["lane-filter", "lane"],
    ["seller-filter", "vendedor"],
    ["filters", "data_inicial"],
    ["filters", "data_final"],
  ];
  fields.forEach(([elementId, name]) => {
    if (parameters.has(name)) {
      const element = elementId === "filters"
        ? filtersForm.elements.namedItem(name)
        : document.getElementById(elementId);
      element.value = parameters.get(name);
    }
  });
}

function saveFilterState(parameters) {
  ["lane", "vendedor", "data_inicial", "data_final"].forEach((name) => {
    if (!parameters.get(name)) {
      parameters.delete(name);
    }
  });
  const query = parameters.toString();
  window.history.replaceState(
    null,
    "",
    query ? `${window.location.pathname}?${query}` : window.location.pathname,
  );
}

async function loadDashboard(persistState = false) {
  // Descarta respostas antigas se uma consulta mais recente terminar primeiro.
  const requestId = ++dashboardRequestId;
  clearError();
  notice.textContent = "Carregando dados...";
  document.getElementById("total-quotes").textContent = "—";
  const savedState = currentData === null && window.location.search.length > 1
    ? new URLSearchParams(window.location.search)
    : null;
  if (savedState && savedState.has("pagina")) {
    currentPage = Number(savedState.get("pagina"));
  }
  const query = savedState || new URLSearchParams(new FormData(filtersForm));
  query.set("pagina", String(currentPage));
  query.set("por_pagina", String(pageSize));
  if (persistState) {
    saveFilterState(query);
  }
  try {
    const response = await fetch(`/api/dashboard?${query.toString()}`, {
      cache: "no-store",
    });
    const data = await response.json();
    if (requestId !== dashboardRequestId) return;
    if (!response.ok) {
      throw new Error(data.detail || "Não foi possível carregar o dashboard.");
    }
    currentData = data;
    updateFilterOptions(data);
    if (savedState) {
      restoreFilterState(savedState);
    }
    // O card recebe o total filtrado, independentemente da página da tabela.
    updateDashboardSummary(data.total);
    renderStatusToggles(data.status_distribution);
    renderMonthlyChart(data);
    renderStatusChart(data);
    renderLaneChart(data);
    renderTopSellersChart(data);
    renderTable(data);
    renderPagination(data);
    notice.textContent = "";
  } catch (error) {
    if (requestId !== dashboardRequestId) return;
    showError(
      error instanceof TypeError && error.message === "Failed to fetch"
        ? "Não foi possível conectar ao servidor do dashboard. Verifique se ele está ativo e tente novamente."
        : error.message,
    );
  }
}

filtersForm.addEventListener("submit", (event) => {
  event.preventDefault();
  currentPage = 1;
  loadDashboard(true);
});

filtersForm.addEventListener("reset", () => {
  currentPage = 1;
  window.setTimeout(() => {
    updateDashboardSummary();
    loadDashboard(true);
  }, 0);
});

["seller-filter", "lane-filter"].forEach((elementId) => {
  document.getElementById(elementId).addEventListener(
    "change",
    () => {
      updateDashboardSummary();
      currentPage = 1;
      loadDashboard(true);
    },
  );
});
["data_inicial", "data_final"].forEach((name) => {
  filtersForm.elements.namedItem(name).addEventListener(
    "change",
    updateDashboardSummary,
  );
});

document.getElementById("previous-page").addEventListener("click", () => {
  if (currentPage > 1) {
    currentPage -= 1;
    loadDashboard(true);
  }
});

document.getElementById("next-page").addEventListener("click", () => {
  if (currentData && currentPage < currentData.pagination.pages) {
    currentPage += 1;
    loadDashboard(true);
  }
});

document.querySelectorAll("th[data-column-index]").forEach((header) => {
  const index = Number(header.dataset.columnIndex);
  header.title = "Duplo clique para ocultar esta coluna";
  header.addEventListener("dblclick", () => toggleColumn(index));
  header.addEventListener("keydown", (event) => {
    if (event.key === "Enter") {
      toggleColumn(index);
    }
  });
});

loadDashboard();
