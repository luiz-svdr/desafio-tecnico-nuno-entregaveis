"""HTTP server for the cotacoes dashboard."""

import argparse
import json
import logging
import math
import sqlite3
import unicodedata
from collections import Counter, defaultdict
from datetime import date
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Mapping, Type
from urllib.parse import parse_qs, urlsplit


ROOT_DIR = Path(__file__).resolve().parents[2]
DEFAULT_DATABASE_PATH = ROOT_DIR / "cotacoes.db"
STATUS_LABELS = {
    "APROVADO": "Aprovado",
    "REJEITADO": "Reprovado",
    "ESTUDO": "Estudo",
    "SEGUNDA OPCAO": "Segunda opção",
}
EMPTY_STATUS_KEY = "__EMPTY__"
EMPTY_LANE_FILTER = "__SEM_LANE__"
ALL_LANES_FILTER = "__TODAS_LANES__"
ALL_SELLERS_FILTER = "__TODOS_VENDEDORES__"
DEFAULT_PAGE_SIZE = 10
MAX_PAGE_SIZE = 100
STATIC_FILES = {
    "/": ("index.html", "text/html; charset=utf-8"),
    "/index.html": ("index.html", "text/html; charset=utf-8"),
    "/style.css": ("style.css", "text/css; charset=utf-8"),
    "/app.js": ("app.js", "text/javascript; charset=utf-8"),
}


class DashboardValidationError(ValueError):
    """Raised when a dashboard filter or pagination value is invalid."""


def _normalize_status(status: str | None) -> tuple[str, str]:
    if status is None or not status.strip():
        return EMPTY_STATUS_KEY, ""

    original = status.strip()
    normalized = unicodedata.normalize("NFKD", original)
    normalized = "".join(char for char in normalized if not unicodedata.combining(char))
    key = " ".join(normalized.upper().split())
    return key, STATUS_LABELS.get(key, original)


def _date_parameter(value: str, label: str) -> str | None:
    if not value:
        return None
    try:
        parsed = date.fromisoformat(value)
    except ValueError:
        raise DashboardValidationError(
            f"O parâmetro {label} deve usar o formato AAAA-MM-DD."
        ) from None
    if parsed.isoformat() != value:
        raise DashboardValidationError(
            f"O parâmetro {label} deve usar o formato AAAA-MM-DD."
        )
    return parsed.isoformat()


def _positive_integer(value: str, label: str, maximum: int | None = None) -> int:
    try:
        result = int(value)
    except ValueError:
        raise DashboardValidationError(f"O parâmetro {label} deve ser um inteiro.") from None
    if result < 1 or (maximum is not None and result > maximum):
        if maximum is None:
            detail = "deve ser maior que zero"
        else:
            detail = f"deve estar entre 1 e {maximum}"
        raise DashboardValidationError(f"O parâmetro {label} {detail}.")
    return result


class DashboardService:
    """Reads, filters, and aggregates cotacoes for dashboard consumers."""

    def __init__(self, database_path: Path):
        self.database_path = Path(database_path)

    def get_dashboard(self, parameters: Mapping[str, str]) -> dict[str, object]:
        if not self.database_path.is_file():
            raise sqlite3.OperationalError(
                f"Banco de dados não encontrado: {self.database_path}"
            )
        lane = parameters.get("lane", "")
        seller = parameters.get("vendedor", "")
        start_date = _date_parameter(parameters.get("data_inicial", ""), "data_inicial")
        end_date = _date_parameter(parameters.get("data_final", ""), "data_final")
        page = _positive_integer(parameters.get("pagina", "1"), "pagina")
        page_size = _positive_integer(
            parameters.get("por_pagina", str(DEFAULT_PAGE_SIZE)),
            "por_pagina",
            MAX_PAGE_SIZE,
        )
        if start_date and end_date and start_date > end_date:
            raise DashboardValidationError(
                "A data inicial não pode ser posterior à data final."
            )

        clauses: list[str] = []
        values: list[str] = []
        if seller and seller != ALL_SELLERS_FILTER:
            clauses.append("vendedor = ?")
            values.append(seller)
        if start_date:
            clauses.append("date(criacao) >= date(?)")
            values.append(start_date)
        if end_date:
            clauses.append("date(criacao) <= date(?)")
            values.append(end_date)
        common_where = f" WHERE {' AND '.join(clauses)}" if clauses else ""

        filtered_clauses = list(clauses)
        filtered_values = list(values)
        if lane == EMPTY_LANE_FILTER:
            filtered_clauses.append("(lane IS NULL OR lane = '')")
        elif lane and lane != ALL_LANES_FILTER:
            filtered_clauses.append("lane = ?")
            filtered_values.append(lane)
        filtered_where = (
            f" WHERE {' AND '.join(filtered_clauses)}" if filtered_clauses else ""
        )

        with sqlite3.connect(self.database_path) as connection:
            connection.row_factory = sqlite3.Row
            all_options = connection.execute(
                "SELECT DISTINCT lane, vendedor FROM cotacoes"
            ).fetchall()
            options_lanes = sorted(
                {row["lane"] for row in all_options if row["lane"]}
            )
            options_sellers = sorted(
                {row["vendedor"] for row in all_options if row["vendedor"]}
            )
            selected_rows = connection.execute(
                """
                SELECT codigo, cliente, criacao, status, modal, paisorigem,
                       paisdestino, vendedor, lane
                FROM cotacoes
                """
                + filtered_where
                + " ORDER BY date(criacao) DESC, codigo DESC",
                filtered_values,
            ).fetchall()
            lane_rows = connection.execute(
                "SELECT lane, COUNT(*) AS volume FROM cotacoes"
                + common_where
                + " GROUP BY lane ORDER BY lane",
                values,
            ).fetchall()

        monthly_counts: dict[str, Counter[str]] = defaultdict(Counter)
        status_counts: Counter[str] = Counter()
        status_labels: dict[str, str] = {}
        seller_approved_counts: Counter[str] = Counter()
        for row in selected_rows:
            status_key, status_label = _normalize_status(row["status"])
            status_counts[status_key] += 1
            status_labels[status_key] = status_label
            seller = str(row["vendedor"] or "").strip()
            if status_key == "APROVADO" and seller:
                # O ranking respeita os filtros ativos e não a página da tabela.
                seller_approved_counts[seller] += 1
            if row["criacao"]:
                month = str(row["criacao"])[:7]
                monthly_counts[month][status_key] += 1

        for status_key, label in STATUS_LABELS.items():
            status_labels.setdefault(status_key, label)
            status_counts.setdefault(status_key, 0)

        statuses = [
            {"key": key, "label": status_labels[key], "count": status_counts[key]}
            for key in sorted(status_labels, key=lambda item: (
                list(STATUS_LABELS).index(item) if item in STATUS_LABELS else len(STATUS_LABELS),
                status_labels[item].casefold(),
            ))
        ]
        monthly = [
            {
                "month": month,
                "statuses": {
                    status["key"]: counts.get(status["key"], 0) for status in statuses
                },
            }
            for month, counts in sorted(monthly_counts.items())
        ]
        # O total usa todo o recorte filtrado, sem limitar à página atual.
        total = len(selected_rows)
        start = (page - 1) * page_size
        page_rows = selected_rows[start : start + page_size]
        quotes = []
        for row in page_rows:
            status_key, status_label = _normalize_status(row["status"])
            quotes.append(
                {
                    "codigo": row["codigo"],
                    "cliente": row["cliente"] or "",
                    "criacao": row["criacao"] or "",
                    "status": {"key": status_key, "label": status_label},
                    "modal": row["modal"] or "",
                    "paisorigem": row["paisorigem"] or "",
                    "paisdestino": row["paisdestino"] or "",
                    "vendedor": row["vendedor"] or "",
                    "lane": row["lane"] or "",
                }
            )

        lane_counts: Counter[str] = Counter()
        for row in lane_rows:
            lane_name = "(Sem lane)" if row["lane"] is None or not row["lane"] else row["lane"]
            lane_counts[lane_name] += row["volume"]
        if any(row["lane"] is None or not row["lane"] for row in lane_rows):
            lane_counts["(Sem lane)"] = sum(
                row["volume"]
                for row in lane_rows
                if row["lane"] is None or not row["lane"]
            )
        lane_distribution = [
            {
                "lane": name,
                "count": count,
                "selected": (
                    lane == EMPTY_LANE_FILTER and name == "(Sem lane)"
                ) or lane == name,
            }
            for name, count in sorted(lane_counts.items(), key=lambda item: item[0])
        ]
        top_sellers = [
            {"vendedor": seller, "qtd_aprovadas": count}
            for seller, count in sorted(
                seller_approved_counts.items(),
                key=lambda item: (-item[1], item[0].casefold()),
            )[:10]
        ]

        return {
            "total": total,
            "top_sellers": top_sellers,
            "monthly": monthly,
            "status_distribution": [
                {
                    "key": status["key"],
                    "label": status["label"] or "(vazio)",
                    "count": status["count"],
                    "percentage": round(status["count"] * 100 / total, 1)
                    if total
                    else 0,
                }
                for status in statuses
                if status["count"] or status["key"] in STATUS_LABELS
            ],
            "lane_distribution": lane_distribution,
            "filters": {
                "lanes": [
                    {"value": lane or EMPTY_LANE_FILTER, "label": lane or "(Sem lane)"}
                    for lane in options_lanes
                ],
                "sellers": options_sellers,
            },
            "quotes": quotes,
            "pagination": {
                "page": page,
                "page_size": page_size,
                "total": total,
                "pages": math.ceil(total / page_size),
            },
        }


def _problem(status: int, title: str, detail: str) -> bytes:
    return json.dumps(
        {
            "type": "about:blank",
            "title": title,
            "status": status,
            "detail": detail,
        },
        ensure_ascii=False,
    ).encode("utf-8")


def create_server(
    database_path: Path,
    host: str = "127.0.0.1",
    port: int = 8000,
) -> ThreadingHTTPServer:
    """Create an HTTP server whose API delegates all data work to the service."""
    service = DashboardService(database_path)

    class DashboardRequestHandler(BaseHTTPRequestHandler):
        def _send(self, status: int, content_type: str, body: bytes) -> None:
            self.send_response(status)
            self.send_header("Content-Type", content_type)
            self.send_header("Content-Length", str(len(body)))
            self.send_header("Cache-Control", "no-store")
            self.send_header("X-Content-Type-Options", "nosniff")
            self.end_headers()
            self.wfile.write(body)

        def do_GET(self) -> None:
            request = urlsplit(self.path)
            if request.path == "/api/dashboard":
                query = parse_qs(request.query, keep_blank_values=True)
                parameters = {key: values[-1] for key, values in query.items()}
                try:
                    result = service.get_dashboard(parameters)
                except DashboardValidationError as error:
                    self._send(
                        400,
                        "application/problem+json; charset=utf-8",
                        _problem(400, "Requisição inválida", str(error)),
                    )
                    return
                except sqlite3.Error:
                    logging.exception("Falha ao consultar o banco do dashboard.")
                    self._send(
                        500,
                        "application/problem+json; charset=utf-8",
                        _problem(
                            500,
                            "Erro interno",
                            "Não foi possível consultar os dados do dashboard.",
                        ),
                    )
                    return
                body = json.dumps(result, ensure_ascii=False).encode("utf-8")
                self._send(200, "application/json; charset=utf-8", body)
                return

            static_file = STATIC_FILES.get(request.path)
            if static_file is None:
                self._send(
                    404,
                    "application/problem+json; charset=utf-8",
                    _problem(404, "Não encontrado", "O recurso solicitado não existe."),
                )
                return

            filename, content_type = static_file
            body = (Path(__file__).parent / filename).read_bytes()
            self._send(200, content_type, body)

    handler: Type[BaseHTTPRequestHandler] = DashboardRequestHandler
    return ThreadingHTTPServer((host, port), handler)


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Inicia o dashboard local de cotações.")
    parser.add_argument("--db", type=Path, default=DEFAULT_DATABASE_PATH, help="arquivo SQLite")
    parser.add_argument("--host", default="127.0.0.1", help="endereço de escuta")
    parser.add_argument("--port", type=int, default=8000, help="porta HTTP")
    args = parser.parse_args(argv)
    if not args.db.is_file():
        parser.error(f"banco de dados não encontrado: {args.db}")

    server = create_server(args.db, args.host, args.port)
    print(f"Dashboard disponível em http://{args.host}:{server.server_port}/")
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\nServidor encerrado.")
    finally:
        server.server_close()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
