-- Tarefa 1.3 - View vw_cotacoes_normalizadas
-- Mantém status nulo e exclui cancelados; a view pode ser recriada.
DROP VIEW IF EXISTS vw_cotacoes_normalizadas;
CREATE VIEW vw_cotacoes_normalizadas AS
SELECT
    codigo,
    cliente,
    criacao,
    paisorigem,
    paisdestino,
    lane,
    modal,
    status,
    CASE
        WHEN vendedor LIKE 'X -%' THEN 'Ex-Funcionário'
        ELSE SUBSTR(TRIM(vendedor), 1, INSTR(TRIM(vendedor) || ' ', ' ') - 1)
    END AS vendedor_normalizado,
    CAST(STRFTIME('%m', criacao) AS INTEGER) AS mes
FROM cotacoes
WHERE status IS NULL OR status <> 'CANCELADO';
