-- Tarefa 1.1 - Rank de vendedores por cotações aprovadas (01/01/2022 a 31/07/2022)
-- Aplica o período inclusivo e as regras de destino e vendedor do enunciado.
WITH aprovadas AS (
    SELECT vendedor, COUNT(*) AS qtd_aprovadas
    FROM cotacoes
    WHERE status = 'APROVADO'
      AND date(criacao) BETWEEN '2022-01-01' AND '2022-07-31'
      AND (paisdestino IS NULL OR paisdestino <> 'BRASIL')
      AND vendedor NOT LIKE 'X -%'
    GROUP BY vendedor
)
SELECT
    vendedor AS nome_vendedor,
    qtd_aprovadas,
    DENSE_RANK() OVER (ORDER BY qtd_aprovadas DESC) AS posicao
FROM aprovadas
ORDER BY posicao, nome_vendedor;
