-- Tarefa 1.2 - Clientes com taxa de aprovação < 20% (01/01/2022 a 31/12/2022, mínimo de 10 cotações)
-- Agrupa por cliente e aplica o mínimo de cotações antes de filtrar pela taxa.
SELECT
    cliente AS nome_cliente,
    COUNT(*) AS total_cotacoes,
    SUM(CASE WHEN status = 'APROVADO' THEN 1 ELSE 0 END) AS cotacoes_aprovadas,
    ROUND(100.0 * SUM(CASE WHEN status = 'APROVADO' THEN 1 ELSE 0 END) / COUNT(*), 2) AS taxa_aprovacao_pct
FROM cotacoes
WHERE date(criacao) BETWEEN '2022-01-01' AND '2022-12-31'
GROUP BY cliente
HAVING COUNT(*) >= 10
   AND 100.0 * SUM(CASE WHEN status = 'APROVADO' THEN 1 ELSE 0 END) / COUNT(*) < 20
ORDER BY taxa_aprovacao_pct ASC;
